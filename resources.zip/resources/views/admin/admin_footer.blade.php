
		<!-- Back to top -->
		<a href="#top" id="back-to-top" ><i class="fa fa-rocket"></i></a>


		<!-- Dashboard Core -->
		<script src="../../assets/js/vendors/jquery-3.2.1.min.js"></script>
		<script src="../../assets/plugins/bootstrap-4.3.1-dist/js/popper.min.js"></script>
		<script src="../../assets/plugins/bootstrap-4.3.1-dist/js/bootstrap.min.js"></script>
		<script src="../../assets/js/vendors/jquery.sparkline.min.js"></script>
		<script src="../../assets/js/vendors/selectize.min.js"></script>
		<script src="../../assets/js/vendors/jquery.tablesorter.min.js"></script>
		<script src="../../assets/js/vendors/circle-progress.min.js"></script>
		<script src="../../assets/plugins/rating/jquery.rating-stars.js"></script>
		<script src="../../assets/plugins/echarts/echarts.js"></script>

		<!-- Fullside-menu Js-->
		<script src="../../assets/plugins/toggle-sidebar/sidemenu.js"></script>


		<!-- Charts Plugin -->
		<script src="../../assets/plugins/chart/Chart.bundle.js"></script>
		<script src="../../assets/plugins/chart/utils.js"></script>

		<!-- Input Mask Plugin -->
		<script src="../../assets/plugins/input-mask/jquery.mask.min.js"></script>

		<!--Morris.js Charts Plugin -->
		<script src="../../assets/plugins/morris/raphael-min.js"></script>
		<script src="../../assets/plugins/morris/morris.js"></script>

        <!-- Scripts -->
        <script src="{{ asset('js/app.js') }}" defer></script>
        <!-- Index Scripts -->
		<script src="../../assets/js/index2.js"></script>

		<!-- Custom scroll bar Js-->
		<script src="../../assets/plugins/scroll-bar/jquery.mCustomScrollbar.concat.min.js"></script>

		


		<!-- Custom Js-->
		<script src="../../assets/js/admin-custom.js"></script>

	</body>
</html>