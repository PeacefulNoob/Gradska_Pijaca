
			<div class="horizontal-main bg-dark-transparent clearfix">
				<div class="horizontal-mainwrapper  clearfix">
					<div class="desktoplogo">
						<a href="/"><img src="/assets//images/brand/logo1.png" alt=""></a>
					</div>
					<div class="desktoplogo-1">
						<a href="/"><img src="/assets//images/brand/logo.png" alt=""></a>
					</div>
					<!--Nav-->
					<nav class="horizontalMenu clearfix d-md-flex">
						<ul class="horizontalMenu-list">
							<li aria-haspopup="true"><a href="/" class="active">Početna </span></a>
							</li>
							<li aria-haspopup="true"><a href="/about">O nama </a></li>
					 
							<li aria-haspopup="true"><a href="/post">Blog </a>
								
							
							</li> 
							<li aria-haspopup="true"><a href="/ad">Oglasi </a>
							

							</li>
						
							<li aria-haspopup="true"><a href="/contact"> Kontakt <span class="wsarrow"></span></a></li>
							
						</ul>
						
					</nav>
					<!--Nav-->
				</div>
			</div>
		</div>