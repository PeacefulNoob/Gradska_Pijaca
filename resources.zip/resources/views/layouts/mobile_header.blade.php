<!-- Mobile Header -->
<div class="horizontal-header clearfix ">
    <div class="container">
        <a id="horizontal-navtoggle" class="animated-arrow"><span></span></a>
        <span class="smllogo"><img src="/assets/images/brand/logo.png" width="120" alt=""/></span>
        <a href="tel:069 964 834" class="callusbtn"><i class="fa fa-phone" aria-hidden="true"></i></a>
    </div>
</div>
<!-- /Mobile Header -->
