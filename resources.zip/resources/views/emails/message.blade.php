<h3>You have a new email via contact form {{ $name }}</h3>
<div>
{{ $messages }}
</div>
<p>Sent by: {{ $email }}</p>